﻿using System;
using System.ComponentModel.Design;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Reflection;
using OfficeOpenXml.FormulaParsing.LexicalAnalysis;
using System.Runtime.CompilerServices;
using System.IO;

namespace CarShoppie
{
    public class Cars
    {
        public string BrandName { get; set; }
        public string ModelName { get; set; }
        public string[] PackageName = new string[2];
        public string[] ToolName = new string[10];
        public int[] ToolWeHaveNumber = new int[10];


    }




    class Program
    {
        static void Main(string[] args)
        {
            string userDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData";
            string carDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData";

            mainmenu:

            Console.WriteLine("WELCOME...");
            Console.WriteLine("PLEASE LOGİN OR SIGN UP...");
            Console.WriteLine("PRESS 1 - LOGIN");
            Console.WriteLine("PRESS 2 - SIGN UP");
            Console.WriteLine("PRESS 8 - EXIT");
            Console.Write("MAKE YOUR CHOICE : ");
            int startingchoice;

            while(!(int.TryParse(Console.ReadLine(), out startingchoice) && (startingchoice==1 || startingchoice==2 || startingchoice==8)))
            {
                Console.Clear();
                Console.WriteLine("INVALID CHOICE... PLEASE TRY AGAIN...");
                Console.WriteLine("PRESS 1 - LOGIN");
                Console.WriteLine("PRESS 2 - SIGN UP");
                Console.WriteLine("PRESS 8 - EXIT");
                Console.WriteLine("MAKE YOUR CHOICE : ");
            }

            if(startingchoice==8) 
            {
                Console.WriteLine("SEE YOU AGAIN...");
            }
            else if (startingchoice==1)  // ---------------------------------------------------------------------------------- LOGIN PARTS -----------------
            {
                string[] users = Directory.GetDirectories(userDataPath).Select(Path.GetFileName).ToArray();

                Console.Clear();
                Console.WriteLine("LOGIN PAGE");
                Console.Write("Username : ");
                string username = Console.ReadLine().ToString();

                bool userHave = false;
                string password;
                string usertype;

                for (int usersCounter = 0; usersCounter < users.Length; usersCounter++)
                {
                    if (users[usersCounter] == username)
                    {
                        Console.Clear();
                        Console.WriteLine("Welcome, " + username);
                        userHave = true;
                        break;
                    }

                }

                if (userHave)
                {
                    Console.Write("Please type your password : ");
                    password = Console.ReadLine();

                    string passwordOfTypedUsername = File.ReadAllText(userDataPath + "\\" + username + "\\password.txt");

                    if(password == passwordOfTypedUsername)
                    {
                        Console.Clear();

                        string userNameSurname = File.ReadAllText(userDataPath + "\\" + username + "\\name_surname.txt");
                        usertype = File.ReadAllText(userDataPath + "\\" + username + "\\usertype.txt");

                        Console.WriteLine("Welcome, " + userNameSurname + " (" + usertype + ")");
                        Console.WriteLine("Press any key to continue...");
                        Console.ReadLine();


                        if (usertype == "admin")
                        {
                            Console.Clear();
                            Console.WriteLine("ADMIN CONTROL UNIT (" + userNameSurname + ")");

                            Console.WriteLine("Type 1 - Show All Cars and Stocks");    
                            Console.WriteLine("Type 2 - Show All Users");

                            Console.WriteLine("Please make your choice : ");
                            int loginAdminCarsOrUsers;

                            while(!(int.TryParse(Console.ReadLine(), out loginAdminCarsOrUsers) && (loginAdminCarsOrUsers==1 || loginAdminCarsOrUsers==2)))
                            {
                                Console.Clear();
                                Console.WriteLine("ADMIN CONTROL UNIT (" + userNameSurname + ")");

                                Console.WriteLine("INVALID CHOICE... PLEASE TRY AGAIN...");

                                Console.WriteLine("Type 1 - Show All Cars and Stocks");
                                Console.WriteLine("Type 2 - Show All Users");
                            }

                        choosecar:

                            if (loginAdminCarsOrUsers == 1)
                            {
                                Console.Clear();

                                string[] carList = Directory.GetDirectories(carDataPath).Select(Path.GetFileName).ToArray();

                                int carNumber = 0;
                                string theCarName = "";
                                string carNamePath = "";

                                for (int carListCounter=0; carListCounter < carList.Length; carListCounter++)
                                {
                                    string[] packageList = Directory.GetDirectories(carDataPath + "\\" + carList[carListCounter]).Select(Path.GetFileName).ToArray();

                                    for(int packageCounter=0; packageCounter < packageList.Length; packageCounter++)
                                    {
                                        carNumber++;

                                        

                                        carNamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter] + "\\car_brand_model_name.txt";

                                        using (StreamReader carName = new StreamReader(carNamePath))
                                        {
                                            theCarName = carName.ReadToEnd();
                                        }

                                        Console.WriteLine(carNumber + " - " + theCarName);
                                    }

                                }

                                

                                carNumber = 0;

                                Console.Write("Please choose the car to the shopping : ");
                                int kacıncıaraba = Convert.ToInt32(Console.ReadLine());
                                string secilmisarabaPath = "";
                                string secilmisarabaParcaPath = "";

                                for (int carListCounter = 0; carListCounter < carList.Length; carListCounter++)
                                {
                                    string[] packageList = Directory.GetDirectories(carDataPath + "\\" + carList[carListCounter]).Select(Path.GetFileName).ToArray();

                                    for (int packageCounter = 0; packageCounter < packageList.Length; packageCounter++)
                                    {
                                        carNumber++;



                                        carNamePath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter] + "\\car_brand_model_name.txt";

                                        using (StreamReader carName = new StreamReader(carNamePath))
                                        {
                                            theCarName = carName.ReadToEnd();
                                        }


                                        if (carNumber == kacıncıaraba)
                                        {
                                            secilmisarabaPath = Directory.GetCurrentDirectory() + "\\theDatabase\\carsTotalData\\" + carList[carListCounter] + "\\" + packageList[packageCounter];
                                            
                                            string[] arabanınparcalar = Directory.GetDirectories(secilmisarabaPath).Select(Path.GetFileName).ToArray();


                                            

                                            string[] arabanınParcalari = Directory.GetDirectories(secilmisarabaPath).Select(Path.GetFileName).ToArray();

                                            Console.Clear();

                                            Console.WriteLine(theCarName + " TOOL LIST\n");
                                            string theParcaStock = "";

                                            for (int parcaCounter=0; parcaCounter < arabanınParcalari.Length; parcaCounter++)
                                            {
                                                string secilmisarabaStockPath = secilmisarabaPath + "\\" + arabanınparcalar[parcaCounter] + "\\stock.txt";


                                                using (StreamReader stock = new StreamReader(secilmisarabaStockPath))
                                                {
                                                    theParcaStock = stock.ReadToEnd();

                                                    if (theParcaStock.Length == 0)
                                                        theParcaStock = "0";
                                                }

                                                Console.WriteLine(arabanınParcalari[parcaCounter] + " - stock : " + theParcaStock);

                                            }


                                            Console.Write("Type 1 to car list menu, Type 2 to main menu : ");
                                            int backtomenu = Convert.ToInt32(Console.ReadLine());

                                            if(backtomenu == 1)
                                            {
                                                Console.Clear();
                                                goto choosecar;
                                            }
                                            else if(backtomenu == 2)
                                            {
                                                Console.Clear();
                                                goto mainmenu;
                                            }

                                            


                                        }
                                    }
                                } // admin cars list end
                            }
                            else if (loginAdminCarsOrUsers == 2)
                            {





                            }
                        // ADMIN CONTROL PAGE END
                        }
                        else if (usertype == "customer")
                        {
                            Console.WriteLine("CUSTOMER CONTROL UNIT \n");


                        }
                        else if (usertype == "dealer")
                        {
                            Console.WriteLine("DEALER CONTROL UNIT \n");

                        }

                    }
                    else
                    {
                        Console.Clear();
                        Console.WriteLine("Invalid password...");
                    }

                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("User was not found...");
                    Console.WriteLine("Please try again or sign up...");
                }






            }
            else if (startingchoice==2)  // ---------------------------------------------------------------------------------- SIGN UP PARTS -----------------
            {
                Console.Clear();
                Console.WriteLine("SIGNUP PAGE \n");
                Console.WriteLine("Username rules...");
                Console.WriteLine("Limitted with 5-20 character"); 
                Console.WriteLine("You can use numerical or alphabetical characters"); 
                Console.WriteLine("You can not use special characters...\n");
                Console.WriteLine();

                Console.Write("Type a Username : ");

                string newUsername = Console.ReadLine();
                bool usernameAlphaNumericControl  = true;

                foreach (char c in newUsername)
                {
                    if (!char.IsLetterOrDigit(c))
                    {
                        usernameAlphaNumericControl = false;
                    }

                }

                bool newUserUnıqueControl = true;
                string[] users = Directory.GetDirectories(userDataPath).Select(Path.GetFileName).ToArray();

                for (int usersCounter = 0; usersCounter < users.Length; usersCounter++)
                {
                    if (users[usersCounter] == newUsername)
                    {
                        newUserUnıqueControl = false;
                    }
                }


                if (newUserUnıqueControl)
                {
                    if (usernameAlphaNumericControl && newUsername.Length >= 5 && newUsername.Length <= 20 && char.IsLetter(newUsername[0]))
                    {
                        Console.Clear();
                        Console.WriteLine("SIGNUP PAGE \n");
                        Console.WriteLine("Password rules...");
                        Console.WriteLine("Limitted with 8-20 character");
                        Console.WriteLine("You must use at least 1 number,");
                        Console.WriteLine("at least 1 uppercase letter, at least 1 lowercase letter,");
                        Console.WriteLine("at least 1 special character from !@#$%&*_+");
                        Console.WriteLine("You can not use space...\n");
                        Console.WriteLine();

                        Console.WriteLine("Your Username : " + newUsername);
                        Console.Write("Please type your Password : ");
                        string newUserPassword = Console.ReadLine();

                        bool passwordRule8_20 = false;
                        bool passwordRuleLeast1Num = false;
                        bool passwordRuleLeast1upper = false;
                        bool passwordRuleLeast1lower = false;
                        bool passwordRuleSpecial = false;
                        bool passwordRuleNoSpace = false;

                        string specialCharacters = "!@#$%&*_+";

                        if (newUserPassword.Length >= 8 && newUserPassword.Length <= 20)
                            passwordRule8_20 = true;

                        for (int passwordStringCounter = 0; passwordStringCounter < newUserPassword.Length; passwordStringCounter++)
                        {
                            if (char.IsDigit(newUserPassword[passwordStringCounter]))
                                passwordRuleLeast1Num = true;

                            if (char.IsUpper(newUserPassword[passwordStringCounter]))
                                passwordRuleLeast1upper = true;

                            if (char.IsLower(newUserPassword[passwordStringCounter]))
                                passwordRuleLeast1lower = true;

                            for (int specialstringCounter = 0; specialstringCounter < specialCharacters.Length; specialstringCounter++)
                            {
                                if (newUserPassword[passwordStringCounter] == specialCharacters[specialstringCounter])
                                    passwordRuleSpecial = true;
                            }

                            if (!newUserPassword.Contains(" "))
                                passwordRuleNoSpace = true;

                        }


                        if (passwordRule8_20 && passwordRuleLeast1Num && passwordRuleLeast1upper && passwordRuleLeast1lower && passwordRuleSpecial && passwordRuleNoSpace)
                        {
                            Console.Clear();
                            Console.WriteLine("SIGNUP PAGE \n");
                            Console.WriteLine("Name Surname rules...");
                            Console.WriteLine("You can not use special characters...\n");
                            Console.WriteLine();

                            Console.WriteLine("Your Username : " + newUsername);
                            Console.WriteLine("Your Username : " + newUserPassword);
                            Console.Write("Please type your Name and Surname : ");

                            string newNameSurname = Console.ReadLine();

                            bool newNameSurnameIsOK = true;

                            for (int nameSurCount=0; nameSurCount<newNameSurname.Length; nameSurCount++)
                            {
                                if (!char.IsLetter(newNameSurname[nameSurCount]))
                                {
                                    if (!(newNameSurname[nameSurCount] == ' '))
                                        newNameSurnameIsOK = false;
                                }
                                    
                            }

                            if (newNameSurnameIsOK)
                            {
                                Console.Clear();
                                Console.WriteLine("SIGNUP PAGE \n");
                                Console.WriteLine("E-Mail rules...");
                                Console.WriteLine("The first character can not be special character...");
                                Console.WriteLine("Your e-mail must contain the character-@...\n");
                                Console.WriteLine();

                                Console.WriteLine("Your Username : " + newUsername);
                                Console.WriteLine("Your Password : " + newUserPassword);
                                Console.WriteLine("Your Name Surname : " + newNameSurname);
                                Console.Write("Please type your E-Mail : ");

                                string newEmail = Console.ReadLine();

                                bool emailFirstCharLetter = false;
                                bool emailHaveAt = false;

                                if (char.IsLetter(newEmail[0]))
                                    emailFirstCharLetter = true;

                                for (int emailStrCount=0; emailStrCount<newEmail.Length; emailStrCount++)
                                {
                                    if (newEmail[emailStrCount] == '@')
                                        emailHaveAt = true;
                                }

                                if (emailFirstCharLetter && emailHaveAt)
                                {
                                    Console.Clear();
                                    Console.WriteLine("SIGNUP PAGE \n");
                                    Console.WriteLine("Phone Number rules...");
                                    Console.WriteLine("The number must contain only numbers...");
                                    Console.WriteLine("The must type your number XXX-XXX-XXXX format...\n");
                                    Console.WriteLine();

                                    Console.WriteLine("Your Username : " + newUsername);
                                    Console.WriteLine("Your Password : " + newUserPassword);
                                    Console.WriteLine("Your Name Surname : " + newNameSurname);
                                    Console.WriteLine("Your E-Mail : " + newEmail);
                                    Console.Write("Please type your Phone Number : ");

                                    string newPhoneNumber = Console.ReadLine();

                                    bool newPhoneOnlyNumbers = true;
                                    bool newPhoneIsTrueFormat = true;

                                    for (int newPhoneCounter=0; newPhoneCounter<12; newPhoneCounter++)
                                    {
                                        if (!char.IsDigit(newPhoneNumber[newPhoneCounter]))
                                        {
                                            if (newPhoneNumber[newPhoneCounter] != '-' )
                                                newPhoneOnlyNumbers = false;
                                        }
                                    }

                                    if (newPhoneNumber.Length != 12)
                                        newPhoneIsTrueFormat = false;

                                    for (int newPhoneCounter = 0; newPhoneCounter < 12; newPhoneCounter++)
                                    {
                                        if (newPhoneCounter == 3 || newPhoneCounter == 7)
                                        {
                                            if (newPhoneNumber[newPhoneCounter] != '-')
                                                newPhoneIsTrueFormat = false;
                                        }
                                        else
                                        {
                                            if (!char.IsDigit(newPhoneNumber[newPhoneCounter]))
                                                newPhoneIsTrueFormat = false;
                                        }

                                    }


                                    if (newPhoneOnlyNumbers && newPhoneIsTrueFormat)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("SIGNUP PAGE \n");
                                        Console.WriteLine("Finally, choose your user type...");
                                        Console.WriteLine("Type 1 - Admin");
                                        Console.WriteLine("Type 2 - Customer");
                                        Console.WriteLine("Type 3 - Dealer\n");
                                        Console.Write("Please make your choice : ");

                                        int newUsertypget = Convert.ToInt32(Console.ReadLine());
                                        string newUserType = "";
                                        bool usertypetrue = true;
                                        string newUserPath = "";

                                        if (newUsertypget == 1)
                                        {
                                            newUserType = "admin";
                                            
                                        }
                                        else if (newUsertypget == 2)
                                        {
                                            newUserType = "customer";
                                        }
                                        else if (newUsertypget == 3)
                                        {
                                            newUserType = "dealer";
                                        }
                                        else
                                        {
                                            Console.Clear();
                                            usertypetrue = false;
                                        }


                                        if (usertypetrue)
                                        {
                                            Console.Clear();
                                            newUserPath = Directory.GetCurrentDirectory() + "\\theDatabase\\userData\\" + newUsername;

                                            string defaultUserDataPath = Directory.GetCurrentDirectory() + "\\theDatabase\\templateFiles_users\\" + newUserType;

                                            Directory.CreateDirectory(newUserPath);

                                            static void DirectoryCopyPaste(string sourcePath, string pastePath)
                                            {
                                                if (!Directory.Exists(sourcePath)) 
                                                    Console.WriteLine("kaynak yok");


                                                foreach (var file in Directory.GetFiles(sourcePath))
                                                    File.Copy(file, Path.Combine(pastePath, Path.GetFileName(file)), true);

                                                foreach (var subfolder in Directory.GetDirectories(sourcePath))
                                                    DirectoryCopyPaste(subfolder, Path.Combine(pastePath, Path.GetFileName(subfolder)));
                                            }


                                            DirectoryCopyPaste(defaultUserDataPath, newUserPath);


                                            string[] newUserDataFiles = new string[6];

                                            newUserDataFiles[0] = newUserPath + "\\username.txt";
                                            newUserDataFiles[1] = newUserPath + "\\password.txt";
                                            newUserDataFiles[2] = newUserPath + "\\name_surname.txt";
                                            newUserDataFiles[3] = newUserPath + "\\email.txt";
                                            newUserDataFiles[4] = newUserPath + "\\phone.txt";
                                            newUserDataFiles[5] = newUserPath + "\\usertype.txt";

                                            using (StreamWriter newUsernameWrite = new StreamWriter(newUserDataFiles[0]))
                                                newUsernameWrite.Write(newUsername);

                                            using (StreamWriter newPasswordWrite = new StreamWriter(newUserDataFiles[1]))
                                                newPasswordWrite.Write(newUserPassword);

                                            using (StreamWriter newNameSurnameWrite = new StreamWriter(newUserDataFiles[2]))
                                                newNameSurnameWrite.Write(newNameSurname);

                                            using (StreamWriter newEmailWrite = new StreamWriter(newUserDataFiles[3]))
                                                newEmailWrite.Write(newEmail);

                                            using (StreamWriter newPhoneWrite = new StreamWriter(newUserDataFiles[4]))
                                                newPhoneWrite.Write(newPhoneNumber);

                                            using (StreamWriter newUsertypeWrite = new StreamWriter(newUserDataFiles[5]))
                                                newUsertypeWrite.Write(newUserType);



                                            Console.WriteLine("Username : " + newUsername);
                                            Console.WriteLine("Password : " + newUserPassword);
                                            Console.WriteLine("Name Sur : " + newNameSurname);
                                            Console.WriteLine("E - Mail : " + newEmail);
                                            Console.WriteLine("Phone Nu : " + newPhoneNumber);
                                            Console.WriteLine("Usertype : " + newUserType);


                                            Console.WriteLine("NEW USER WAS CREATED...");

                                        }
                                        else // user type control else
                                        { 
                                            Console.Clear();
                                            Console.WriteLine("invalid user type choose...");
                                        }

                                    }
                                    else // phone number control else
                                    {
                                        Console.Clear();
                                        Console.WriteLine("invalid phone number...");
                                    }

                                }
                                else  // email control else
                                {
                                    Console.Clear();
                                    Console.WriteLine("invalid email...");
                                }

                            }
                            else  // name surname control else
                            {
                                Console.Clear();
                                Console.WriteLine("invalid name surname...");
                            }

                        }
                        else  // password control else
                        {
                            Console.Clear();
                            Console.WriteLine("invalid password...");
                        }

                    }
                    else  // username control else
                    {
                        Console.Clear();
                        Console.WriteLine("invalid username...");
                    }

                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("The username is already using. Please try again...");
                }

            }
        }
    }
}